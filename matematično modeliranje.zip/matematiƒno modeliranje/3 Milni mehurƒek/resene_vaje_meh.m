% leto�nji kviz

c = 83; n = 21+2*mod(c, 21);
a=-1; b=1;
r