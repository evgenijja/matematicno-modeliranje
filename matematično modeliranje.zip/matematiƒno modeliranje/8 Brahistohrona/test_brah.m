% test brahistohrone
T1 = [1 1];
T2 = [3 0]; 
risi_brah(T1,T2);