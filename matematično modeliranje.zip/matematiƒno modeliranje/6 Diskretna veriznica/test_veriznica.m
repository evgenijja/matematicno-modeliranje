% test: diskretna verizinica
% a)
zac = [0 6;0 1];

L = [2 1 1 1 1 2];

%M = [1 0.5 1 1 0.5 1];
M = [1 0.5 5 1 0.5 1];

risi_veriznica(zac,L,M);

