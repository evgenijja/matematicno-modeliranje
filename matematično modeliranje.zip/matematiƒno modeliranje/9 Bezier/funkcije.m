% funkcije in kaj delajo

% deCasteljau
% DE_CASTELJAU izracuna tocko na  Bezierovi krivulji pri parametru t