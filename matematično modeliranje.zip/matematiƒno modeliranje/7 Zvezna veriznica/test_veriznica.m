% test zvezne veriznice

% a)
l = 10;
T1 = [0 0];
T2 = [6 3];
isci_z(T1,T2,l,1,1e-10);
risi_ver(T1,T2,l,1e-10);

